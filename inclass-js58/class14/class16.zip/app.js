// replace this entire code block with the config found in the firebase dashboard
// for your created database
var config = {
  apiKey: "<API_KEY>",
  authDomain: "<PROJECT_ID>.firebaseapp.com",
  databaseURL: "https://<DATABASE_NAME>.firebaseio.com",
  storageBucket: "<BUCKET>.appspot.com",
  messagingSenderId: "<SENDER_ID>",
};
firebase.initializeApp(config);

// Get a reference to the database service
var database = firebase.database();

database.ref("/hello-world").set({ hello: "world" })
